package com.playground.ecommercedemo.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.playground.ecommercedemo.dao.UserDAO;
import com.playground.ecommercedemo.model.User;

@RestController
@RequestMapping(path = "/user")
public class UserController {

	@Autowired
	private UserDAO userDao;

	@GetMapping(path = "/readallusers", produces = "application/json")
	public List<User> getAllUsers() {
		return userDao.getAllUser();
	}

	@PostMapping(path = "/adduser", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> addUser(@RequestBody User user) {

		userDao.addUser(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}

	@PostMapping(path = "/updateuser", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> updateUser(@RequestBody User user) {

		userDao.updateUser(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}

	@PostMapping(path = "/deleteuser", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> deleteUser(@RequestBody User user) {

		userDao.deleteUser(user.getId());

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}
}