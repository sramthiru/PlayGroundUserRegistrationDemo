package com.playground.ecommercedemo.dao;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Repository;

import com.playground.ecommercedemo.model.User;

@Repository
public class UserDAO {
	private static final String COMMA_DELIMITER = ",";

	private static final String path = "C:\\subbu\\test1\\test1.csv";

	public List<User> getAllUser() {
		List<User> listUser = readFile(path);
		return listUser;
	}

	public static List<User> readFile(String path) {

		List<User> listData = new ArrayList<User>();
		try (Stream<String> stream = Files.lines(Paths.get(path))) {
			listData = stream.map(line -> {

				String[] det = line.split(",");
				User data = new User(Integer.valueOf(det[0]), det[1], det[2], det[3], Integer.valueOf(det[4]), det[5]);
				return data;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listData;
	}

	public void addUser(User user) {

		List<User> userList = readFile(path);
		userList.add(user);
		writeFile(userList);
	}

	public void updateUser(User user) {

		List<User> listUser = readFile(path);
		List<User> listUserInfo = new ArrayList<User>();
		for (User userInfo : listUser) {
			if (userInfo.getId() == user.getId()) {
				listUserInfo.add(user);
			} else {
				listUserInfo.add(userInfo);
			}
		}
		writeFile(listUserInfo);
	}

	public void deleteUser(int id) {

		List<User> listuser = readFile(path);
		List<User> listUserInfo = new ArrayList<User>();
		for (User user : listuser) {
			if (user.getId() == id) {
				System.out.println("The user id removed is: " + id);
			} else {
				listUserInfo.add(user);
			}
		}
		writeFile(listUserInfo);
	}

	public void writeFile(List<User> fileContents) {

		FileWriter fileWriter = null;
		try {
			Path filePath = Paths.get(path);
			Files.deleteIfExists(filePath);
			fileWriter = new FileWriter(path, true);
			for (User data : fileContents) {
				fileWriter.append(String.valueOf(data.getId()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(data.getFirstName());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(data.getLastName());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(data.getEmail());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(data.getAge()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(data.getDeliveryAddress());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(System.lineSeparator());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}