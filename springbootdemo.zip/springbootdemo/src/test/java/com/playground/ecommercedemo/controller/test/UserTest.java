package com.playground.ecommercedemo.controller.test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.playground.ecommercedemo.controller.UserController;
import com.playground.ecommercedemo.dao.UserDAO;
import com.playground.ecommercedemo.model.User;

public class UserTest {

	@InjectMocks
	UserController user;

	@Mock
	UserDAO dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getUsers() {

		List<User> userslist = new ArrayList<User>();

		User userInfo = new User(1, "Ram", "Raja", "dd@gmail.com", 29, "Columbus");
		userslist.add(userInfo);

		when(dao.getAllUser()).thenReturn(userslist);

		List<User> userActualList = user.getAllUsers();

		verify(dao, times(1)).getAllUser();
		

	}
}
